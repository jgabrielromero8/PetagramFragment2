package com.gabo.petagram;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.gabo.petagram.R;
import com.gabo.petagram.adapter.MascotaAdapter;
import com.gabo.petagram.adapter.MascotaPerfilAdapter;
import com.gabo.petagram.pojo.Mascota;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class PerfilMascotaFragment extends Fragment {

    RecyclerView rvPerfilMascota;
    private ArrayList<Mascota> mascotasPerfil;

    public PerfilMascotaFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_perfil_mascota,container,false);


        rvPerfilMascota = (RecyclerView) view.findViewById(R.id.rv_profile_fotos);

        rvPerfilMascota.setLayoutManager(new GridLayoutManager(getActivity(), 3));

        inicializarMascotas();
        inicializarAdaptador();

        return view;


}
    //inicializar mascotas
    public void inicializarMascotas(){
        mascotasPerfil = new ArrayList<Mascota>();
        mascotasPerfil.add(new Mascota(getResources().getString(R.string.string_peludo), R.drawable.img_lanudo, 2));
        mascotasPerfil.add(new Mascota(getResources().getString(R.string.string_peludo), R.drawable.img_lanudo, 10));
        mascotasPerfil.add(new Mascota(getResources().getString(R.string.string_peludo), R.drawable.img_lanudo, 2));
        mascotasPerfil.add(new Mascota(getResources().getString(R.string.string_peludo), R.drawable.img_lanudo, 5));
        mascotasPerfil.add(new Mascota(getResources().getString(R.string.string_peludo), R.drawable.img_lanudo, 2));
        mascotasPerfil.add(new Mascota(getResources().getString(R.string.string_peludo), R.drawable.img_lanudo, 4));
        mascotasPerfil.add(new Mascota(getResources().getString(R.string.string_peludo), R.drawable.img_lanudo, 1));
        mascotasPerfil.add(new Mascota(getResources().getString(R.string.string_peludo), R.drawable.img_lanudo, 2));
    }
    // inicializar adaptador
    public void inicializarAdaptador(){
        MascotaPerfilAdapter mascotaAdapter = new MascotaPerfilAdapter(mascotasPerfil);
        rvPerfilMascota.setAdapter(mascotaAdapter);
    }
}
