package com.gabo.petagram;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.MenuItem;

import com.gabo.petagram.adapter.MascotaAdapter;
import com.gabo.petagram.pojo.Mascota;

import java.util.ArrayList;
import java.util.Collections;

public class MascotaFavoritaActivity extends AppCompatActivity {

    Toolbar actionBar;
    RecyclerView rvMascotas;
    ArrayList<Mascota> mascotas;
    ArrayList<Mascota> mascotasOrdenMeGusta;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mascota_favorita);

        actionBar = (Toolbar) findViewById(R.id.actionBar);
        setSupportActionBar(actionBar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        rvMascotas = (RecyclerView) findViewById(R.id.rvMascotas);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvMascotas.setLayoutManager(linearLayoutManager);

        inicializarMascotas();
        inicializarAdapter();
    }

    private void inicializarAdapter() {
        MascotaAdapter mascotaAdapter = new MascotaAdapter(mascotas);
        rvMascotas.setAdapter(mascotaAdapter);
    }


    private void inicializarMascotas() {
        mascotas = (ArrayList<Mascota>) getIntent().getSerializableExtra("mascotas");
        mascotasOrdenMeGusta = new ArrayList<Mascota>();

        Collections.sort(mascotas, Mascota.SortByMeGusta);

        for(int n=0;n<=4;n++){
            mascotasOrdenMeGusta.add(mascotas.get(n));
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME){
            if (keyCode == KeyEvent.KEYCODE_HOME){
                intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
            }
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
