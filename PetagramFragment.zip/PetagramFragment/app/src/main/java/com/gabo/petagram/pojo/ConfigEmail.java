package com.gabo.petagram.pojo;

/**
 * Created by galael on 13/08/17.
 */

public class ConfigEmail {
    public static final String EMAIL ="jgabriel.romero@gmail.com";
    public static final String PASSWORD ="_0097042349JGR";
}
