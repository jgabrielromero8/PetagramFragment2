package com.gabo.petagram;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.gabo.petagram.adapter.MascotaAdapter;
import com.gabo.petagram.pojo.Mascota;

import java.util.ArrayList;

/**
 * Created by galael on 13/08/17.
 */


public class MascotaFragment extends Fragment {
    RecyclerView rvMascotas;
    public static  ArrayList<Mascota> mascotas;

    public MascotaFragment(){

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_mascota,container,false);

        rvMascotas = (RecyclerView) view.findViewById(R.id.rvMascotas);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvMascotas.setLayoutManager(linearLayoutManager);

        inicializarMascotas();
        inicializarAdapter();


        return view;


    }

    private void inicializarMascotas() {
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota(getResources().getString(R.string.string_alita), R.drawable.img_alita, 3));
        mascotas.add(new Mascota(getResources().getString(R.string.string_conejito), R.drawable.img_conejito, 10));
        mascotas.add(new Mascota(getResources().getString(R.string.string_espanto), R.drawable.img_espanto, 4));
        mascotas.add(new Mascota(getResources().getString(R.string.string_lanudo), R.drawable.img_lanudo, 6));
        mascotas.add(new Mascota(getResources().getString(R.string.string_mem), R.drawable.img_mem, 7));
    }

    private void inicializarAdapter() {
        MascotaAdapter mascotaAdapter = new MascotaAdapter(mascotas);
        rvMascotas.setAdapter(mascotaAdapter);
    }
}
